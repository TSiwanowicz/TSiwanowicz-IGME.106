﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TS_OORefactoring
{
    class Player
    {
        private string name;
        private int score;
        Random generator;

        public string Name
        {
            get
            {
                return name;
            }
        }

        public int Score
        {
            get
            {
                return score;
            }
        }

        public Player(string name, Random generator)
        {
            this.name = name;
            this.generator = generator;
            score = generator.Next(0, 101);
        }

        public void PrintInfo()
        {
        }

    }
}
