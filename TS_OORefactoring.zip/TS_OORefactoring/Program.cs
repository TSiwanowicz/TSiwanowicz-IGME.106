﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TS_OORefactoring
{
    class Program
    {
        static void Main(string[] args)
        {
            // Find out how many players the user actually wants
            bool ifValid;
            int numPlayers;
            Random rng = new Random();
            do
            {
                Console.Write("Enter number of players (up to 10): ");
                ifValid = int.TryParse(Console.ReadLine(), out numPlayers);
                if (numPlayers < 0 || numPlayers > 10)
                {
                    ifValid = false;
                }
            }
            while (ifValid == false);

            Player[] playerArray = new Player[numPlayers];

            // Get the names
            Console.WriteLine();
            for (int i = 0; i < numPlayers; i++)
            {
                Console.Write("Enter player {0}'s name: ", i);
                playerArray[i] = new Player(Console.ReadLine().Trim().ToUpper(), rng);
            }

            // Print the player info
            Console.WriteLine("");
            for (int i = 0; i < numPlayers; i++)
            {
                Console.WriteLine("Player {0}, {1}, has a score of {2}", i, playerArray[i].Name, playerArray[i].Score);
            }

            // Print the winner
            int maxScore = playerArray[0].Score;
            int winningIndex =0;
            for (int i = 0; i < numPlayers; i++)
            {
                if (playerArray[i].Score > maxScore)
                {
                    maxScore = playerArray[i].Score;
                    winningIndex = i;
                }
            }
            Console.WriteLine("\nThe winner is {0}!", playerArray[winningIndex].Name);

            Console.ReadLine();

        }
    }
}
